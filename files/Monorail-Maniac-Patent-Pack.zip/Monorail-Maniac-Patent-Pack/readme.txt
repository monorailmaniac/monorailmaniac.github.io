All PDFs were retrieved from the United States Patent and Trademark Office website (uspto.gov)
